// src/store/index.ts
import { configureStore } from '@reduxjs/toolkit'
import {
    persistStore,
    persistReducer,
    FLUSH,
    REHYDRATE,
    PAUSE,
    PERSIST,
    PURGE,
    REGISTER
} from 'redux-persist'
import storage from 'redux-persist/lib/storage'

// Import all your slices
import tokenReducer from './tokenSlice'
import walletReducer from './walletSlice'

// Array of SLICE NAMES that should be PERSISTED
const PERSISTED_SLICES: string[] = [
    'token',
    'wallet'
]

// Array of SLICE NAMES that should NOT be persisted
const NON_PERSISTED_SLICES: string[] = [
    // Add more slice names here that you don't want to persist
]

// Object mapping slice names to their reducers (PERSISTED)
const PERSISTED_REDUCERS: Record<string, any> = {
    token: tokenReducer,
    wallet: walletReducer
}

// Object mapping slice names to their reducers (NON-PERSISTED)
const NON_PERSISTED_REDUCERS: Record<string, any> = {
    // Add more non-persisted reducers here
}

// Create persist config
const persistConfig = {
    key: 'root',
    storage,
    whitelist: PERSISTED_SLICES // Only persist slices in this array
}

// Apply persistReducer to the combined reducers that should be persisted
const rootReducer: Record<string, any> = {}

// Add persisted reducers with persistReducer applied
PERSISTED_SLICES.forEach(sliceName => {
    if (PERSISTED_REDUCERS[sliceName]) {
        rootReducer[sliceName] = persistReducer(
            { ...persistConfig, key: `root-${sliceName}`, storage },
            PERSISTED_REDUCERS[sliceName]
        )
    }
})

// Add non-persisted reducers directly
NON_PERSISTED_SLICES.forEach(sliceName => {
    if (NON_PERSISTED_REDUCERS[sliceName]) {
        rootReducer[sliceName] = NON_PERSISTED_REDUCERS[sliceName]
    }
})

export const store = configureStore({
    reducer: rootReducer,
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware({
            serializableCheck: {
                ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
            },
        }),
})

export const persistor = persistStore(store)

// Define RootState interface explicitly
export interface RootState {
    token: {
        accessToken: string | null
        refreshToken: string | null
        expiration: number | null
        userId: number | null
    }
    wallet: {
        walletData: import('@/types/api').WalletData | null
        loading: boolean
        error: string | null
    }
    // Add other slices here as needed
}

export type AppDispatch = typeof store.dispatch