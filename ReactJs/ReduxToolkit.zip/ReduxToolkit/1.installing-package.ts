npm install @reduxjs/toolkit react-redux redux-persist
npm install --save-dev @types/js-cookie

